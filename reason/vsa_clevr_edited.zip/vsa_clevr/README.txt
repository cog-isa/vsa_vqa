clevr_vsa_svm -  парсит сцену и сохраняет в pickle
    --clevr_scenes
    /home/alexey/projects/clevr-vsa/data/CLEVR_v1.0/scenes/CLEVR_val_scenes.json
    --scene_idx
    0

test_reasoner - пример как использовать модули

vsa_scene_parser - парсит описание сцены из CLEVR_val_scenes.json

vsa_reasoner - класс с модулями программ